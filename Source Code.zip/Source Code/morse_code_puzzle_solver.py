from abc import ABC, abstractmethod
import random

class MorseCodePuzzle(ABC):
    @abstractmethod
    def display_puzzle(self):
        pass

    @abstractmethod
    def check_answer(self, user_answer):
        return False

    @abstractmethod
    def give_hint(self):
        pass

class SimpleDecodePuzzle(MorseCodePuzzle):
    def __init__(self, message, correct_answer):
        self.message = message
        self.correct_answer = correct_answer

    def display_puzzle(self):
        print(f"Decode the following Morse code: {self.message}")

    def check_answer(self, user_answer):
        return user_answer.lower() == self.correct_answer.lower()

    def give_hint(self):
        # Provide a part of the answer
        return f"Hint: The first few letters are {self.correct_answer[:len(self.correct_answer) // 2]}"

class PuzzleManager:
    def __init__(self, puzzles=None):
        self.puzzles = puzzles if puzzles else []
        self.current_puzzle = None

    def add_puzzle(self, puzzle):
        self.puzzles.append(puzzle)

    def select_puzzle(self):
        if self.puzzles:
            self.current_puzzle = random.choice(self.puzzles)
            self.current_puzzle.display_puzzle()

    def get_hint(self):
        if self.current_puzzle:
            return self.current_puzzle.give_hint()

    def check_puzzle_answer(self, user_answer):
        if self.current_puzzle:
            return self.current_puzzle.check_answer(user_answer)
        return False
