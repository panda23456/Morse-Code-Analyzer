from collections import Counter
from morse_code_converter import Morse_Code_Converter
import datetime

class FrequencyAnalyzer:
    def __init__(self):
        self.stopwords = set()
        with open('stopwords.txt', 'r') as f:
            stopwords = f.read().splitlines()
            self.stopwords = set(word.upper() for word in stopwords)
        self.converter = Morse_Code_Converter()

    def analyze_frequencies(self, morse_code):
        plain_text = self.converter.morse_to_text(morse_code)
        words = plain_text.upper().split()
        freq = Counter(words)
        keywords = {word: count for word, count in freq.items()}

        report = ''
        distinct_counts = []
        for count in keywords.values():
            if count not in distinct_counts:
                #storing distinct counts(frequencies)
                distinct_counts.append(count)
        distinct_counts.sort()

        # Summary of Morse words grouped, and sorted by frequencies
        for count in distinct_counts:
            report += f"*** Morse Words with frequency => {count}\n"
            temp_keywords = {word: count_word for word, count_word in keywords.items() if count_word == count}
            # Sort words by Morse code length desc, and sort words with the same length by alphabetical order
            sorted_keywords = sorted(temp_keywords.items(), key=lambda x: (-len(self.converter.text_to_morse(x[0])), x[0]))
            for word, count in sorted_keywords:
                morse_word = self.converter.text_to_morse(word)
                if word not in self.stopwords:
                    report += f"[{morse_word}]=> {word}(*)\n"
                else:
                    report += f"[{morse_word}]=> {word}\n"
            report += '\n'

        #List of keywords sorted by frequencies
        distinct_counts.sort(reverse= True)
        report += f"*** Keywords sorted by Frequency\n"
        #sort words by freq desc
        for count in distinct_counts:
            temp_keywords = {word: count_word for word, count_word in keywords.items() if count_word == count}
            #sort words with same frequency by alphabetical order
            sorted_keywords = sorted(temp_keywords.items(), key=lambda x: (x[0]))
            for word, count in sorted_keywords:
                #check if word is not a stopword
                if word not in self.stopwords:
                    report += f"{word}({count})\n"

        return report

    def generate_report(self, morse_code):
        plain_text = self.converter.morse_to_text(morse_code)
        #Time stamp indicating the date and time that the report was generated
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report = f"**********************************************\n"
        report += f"   REPORT GENERATED ON: {timestamp}\n"
        report += f"**********************************************\n\n"
        #Decoded morse text
        report += f"*** Decoded Morse Text\n{plain_text}\n\n"
        report += self.analyze_frequencies(morse_code)
        return report
    
    def generate_graph(self, morse_code):
        # Time stamp indicating the date and time that the report was generated
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report = f"***********************************************************\n"
        report += f"         REPORT GENERATED ON: {timestamp}\n"
        report += f"***********************************************************\n\n"

        plain_text = self.converter.morse_to_text(morse_code)
        words = plain_text.upper().split()
        freq = Counter(words)
        keywords = {word: count for word, count in freq.items()}

        distinct_counts = []
        for count in keywords.values():
            if count not in distinct_counts:
                # storing distinct counts(frequencies)
                distinct_counts.append(count)
        distinct_counts.sort(reverse=True)

        bar_list = []
        morse_list = []
        plain_text_list = []
        # List of keywords sorted by frequencies
        for count in distinct_counts:
            temp_keywords = {word: count_word for word, count_word in keywords.items() if count_word == count}
            # sort words by length desc, and sort words with same length by alphabetical order
            sorted_keywords = sorted(temp_keywords.items(), key=lambda x: (x[0]))
            for word, count in sorted_keywords:
                # check if word is not a stopword
                if word not in self.stopwords:
                    temp_bar = ""
                    for i in range(count):
                        temp_bar += '*' + '\n'
                    bar_list.append(temp_bar.rstrip('\n'))
                    # Get Morse code for the word
                    morse_code_word = self.converter.text_to_morse(word)
                    morse_list.append(morse_code_word)
                    plain_text_list.append(word)

        # Determine the maximum height of the bars
        max_height = max(len(bar.split('\n')) for bar in bar_list)

        # Adjust each bar to be of equal height by padding with spaces at the top as necessary
        adjusted_bars = []
        for bar in bar_list:
            lines = bar.split('\n')
            padded_bar = [' '] * (max_height - len(lines)) + lines
            adjusted_bars.append(padded_bar)

        # Concatenate the bars side-by-side with a leading space and 9 spaces between bars
        combined_lines = []
        for i in range(max_height):
            combined_line = ' ' + '         '.join(bar[i] for bar in adjusted_bars)
            combined_lines.append(combined_line)

        for line in combined_lines:
            report += line + '\n'

        report += 59 * '_' + '\n'

        # Prepare vertical Morse and plain text side-by-side
        morse_plain_combined = []
        max_morse_plain_height = max(len(morse) for morse in morse_list)

        # Adjust Morse and plain text lists to match the maximum height
        for i in range(len(morse_list)):
            morse = morse_list[i]
            plain_text = plain_text_list[i]
            padded_morse = list(morse) + [' '] * (max_morse_plain_height - len(morse))
            padded_plain_text = list(plain_text) + [' '] * (max_morse_plain_height - len(plain_text))

            combined_morse_plain = [morse_char + ' ' + plain_char for morse_char, plain_char in zip(padded_morse, padded_plain_text)]
            morse_plain_combined.append(combined_morse_plain)

        # Concatenate the morse code and plain text columns side-by-side with 8 spaces between each pair
        for i in range(max_morse_plain_height):
            combined_line = ' ' + '       '.join(morse_plain_combined[j][i] for j in range(len(morse_plain_combined)))
            report += combined_line + '\n'

        return report

