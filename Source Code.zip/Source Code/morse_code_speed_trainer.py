import time
class MorseCodeSpeedTrainer:
    def __init__(self, converter):
        self.converter = converter

    def start_training(self):
        levels = [
            {'speed': 3, 'text': "hello world"},
            {'speed': 5, 'text': "sos"},
            {'speed': 7, 'text': "quick brown fox jumps over the lazy dog"}
        ]

        print("\nWelcome to the Morse Code Speed Trainer!\n")
        for level in levels:
            #speed rate that the user should be able to recognize and transcribe the Morse code
            print(f"Level {levels.index(level) + 1}: Speed {level['speed']} characters per second.")
            morse_code = self.converter.text_to_morse(level['text'])
            print(f"Morse Code to transcribe: {morse_code}")
            start_time = time.time()

            user_input = input("Enter your transcription of the Morse code: ")
            duration = time.time() - start_time
            correct = user_input.lower().replace(" ", "") == level['text'].replace(" ", "")

            if correct:
                print(f"Correct! Time taken: {duration:.2f} seconds")
            else:
                print("Incorrect. Correct answer was:", level['text'])
            print("\nNext level...\n")

        print("Training complete!")