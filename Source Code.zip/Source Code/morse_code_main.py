from morse_code_converter import Morse_Code_Converter
from frequency_analyser import FrequencyAnalyzer
from morse_code_speed_trainer import MorseCodeSpeedTrainer
from morse_code_puzzle_solver import PuzzleManager, SimpleDecodePuzzle

class Morse_Code_Main:
    def __init__(self):
        self._converter = Morse_Code_Converter()
        self._analyzer = FrequencyAnalyzer()
        self._speed_trainer = MorseCodeSpeedTrainer(self._converter)
        self._puzzle_manager = PuzzleManager([
            SimpleDecodePuzzle("-- .- -. -.-", "tank"),
            SimpleDecodePuzzle(".--. .. -.-. -. .. -.-.", "picnic")
        ])

    def start(self):
        infoText = ""
        infoText += '\n' + '*' * 57
        infoText += '\n' + '* ' + "ST1507 DSAA: Morse Code Message Analyser" + (' ' * 14) + '*'
        infoText += '\n' + '*' + '_' * 55 + '*'
        infoText += '\n' + '*' + ' ' * 55 + '*'
        infoText += '\n' + '*  ' + "- Done by: Loh Yip Khai(2317454)" + (' ' * 21) + '*'
        infoText += '\n' + '*  ' + "- Class DAAA/2A/03" + (' ' * 35) + '*'
        infoText += '\n' + '*' * 57
        infoText += '\n' * 3 + "Press Enter, to continue...."
        print(infoText)
        while True:
            if not self._show_selection_menu(): #if return false, aka choice == 7, break out of loop
                break

    def _show_selection_menu(self):
        choiceList = ["Convert Text To Morse Code", "Convert Morse Code To Text", "Generate Morse Word Frequency Report",
        "Generate Morse Keyword Frequency Graph", "Morse Code Speed Trainer", "Morse Code Puzzler Solver", "Exit"]
        selectionText = ""
        selectionText += '\n' + "Please select your choice ('1', '2', '3', '4', '5', '6', '7'):"
        for i in range(len(choiceList)):
            selectionText += '\n'
            selectionText += f"    {i + 1}. {choiceList[i]}"
        selectionText += '\n' + "Enter choice:"
        choice = input(selectionText)
        
        if choice == '1':
            self._convert_text_to_morse()
        elif choice == '2':
            self._convert_morse_to_text()
        elif choice == '3':
            self._generate_frequency_report()
        elif choice == '4':
            self._generate_keyword_graph()
        elif choice == '5':
            self._speed_trainer.start_training()
        elif choice == '6':
            self._start_puzzle_solver()
        elif choice == '7':
            print("\n\nBye, thanks for using ST1507 DSAA: MorseCode Message Analyser")
            return False
        else:
            print('Invalid input! Please try again')
        input("\nPress Enter, to continue....")
        return True
    
    def _convert_text_to_morse(self):
        input_file = input('\n'+ "Please enter input file: ")
        output_file = input("Please enter output file: ")
        try:
            with open(input_file, 'r') as f:
                text = f.read()
        except FileNotFoundError:
            print("Error: Input file not found.")
            return
        morse_code = self._converter.text_to_morse(text)
        with open(output_file, 'w') as f:
            f.write(morse_code)
        # print(f"Text to Morse Code conversion complete. Output written to {output_file}")

    def _convert_morse_to_text(self):
        input_file = input('\n'+ "Please enter input file: ")
        output_file = input("Please enter output file: ")
        try:
            with open(input_file, 'r') as f:
                morse_code = f.read()
        except FileNotFoundError:
            print("Error: Input file not found.")
            return
        text = self._converter.morse_to_text(morse_code)
        with open(output_file, 'w') as f:
            f.write(text)
        # print(f"Morse Code to Text conversion complete. Output written to {output_file}")

    def _generate_frequency_report(self):
        input_file = input("\nPlease enter input file: ")
        output_file = input("Please enter output file: ")
        try:
            with open(input_file, 'r') as f:
                morse_code = f.read()
        except FileNotFoundError:
            print("Error: Input file not found.")
            return
        report = self._analyzer.generate_report(morse_code)
        with open(output_file, 'w') as f:
            f.write(report)
        # print(f"Morse Word Frequency Report generated. Output written to {output_file}")

    def _generate_keyword_graph(self):
        input_file = input("\nPlease enter input file: ")
        output_file = input("Please enter output file: ")
        try:
            with open(input_file, 'r') as f:
                morse_code = f.read()
        except FileNotFoundError:
            print("Error: Input file not found.")
            return
        graph = self._analyzer.generate_graph(morse_code)
        with open(output_file, 'w') as f:
            f.write(graph)
        # print(f"Morse Keyword Frequency Graph generated. Output written to {output_file}")

    def _start_puzzle_solver(self):
        print("Welcome to the Morse Code Puzzle Solver!\n")
        self._puzzle_manager.select_puzzle()
        while True:
            user_input = input("Enter your solution or type 'hint' for a hint: ")
            if user_input.lower() == 'hint':
                print(self._puzzle_manager.get_hint())
            elif self._puzzle_manager.check_puzzle_answer(user_input):
                print("Correct answer! Well done.")
                break
            else:
                print("That's not correct. Try again or type 'hint' for a hint.")


    
        
