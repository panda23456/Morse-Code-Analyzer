from morse_code_main import Morse_Code_Main

main = Morse_Code_Main()
main.start()
    




